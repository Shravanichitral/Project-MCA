package com.example.adminorder

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.adminorder.adapter.OrderDetailsAdapter
import com.example.adminorder.databinding.ActivityOrderDetailsBinding
import com.example.adminorder.model.OrderDetails

class OrderDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOrderDetailsBinding
    private var userName: String? = null
    private var phoneNumber: String? = null
    private var totalPrice: String? = null
    private var foodNames: ArrayList<String> = arrayListOf()
    private var foodImages: ArrayList<String> = arrayListOf()
    private var foodQuantities: ArrayList<Int> = arrayListOf()
    private var foodPrices: ArrayList<String> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        getDataFromIntent()
    }

    private fun getDataFromIntent() {
        val receivedOrderDetails = intent.getParcelableExtra<OrderDetails>("UserOrderDetails")
        receivedOrderDetails?.let { orderDetails ->
            userName = orderDetails.userName
            foodNames = orderDetails.foodNames as ArrayList<String>
            foodImages = orderDetails.foodImages as ArrayList<String>
            foodQuantities = orderDetails.foodQuantities as ArrayList<Int>
            phoneNumber = orderDetails.phoneNumber
            foodPrices = orderDetails.foodPrices as ArrayList<String>
            totalPrice = orderDetails.totalPrice
            setUserDetail()
            setAdapter()
        }
    }

    private fun setUserDetail() {
        binding.name.text = userName
        binding.phone.text = phoneNumber
        binding.totalPay.text = totalPrice
    }

    private fun setAdapter() {
        binding.orderDetailRecyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = OrderDetailsAdapter(this, foodNames, foodImages, foodQuantities, foodPrices)
        binding.orderDetailRecyclerView.adapter = adapter
    }
}
