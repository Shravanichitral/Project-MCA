package com.example.adminorder.model

data class UserModel(

    val name:String?=null,
    val email:String?=null,
    val phone:String?=null,
)
