package com.example.adminorder

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.adminorder.databinding.ActivityAddItemBinding
import com.example.adminorder.model.AllMenu
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage

class AddItemActivity : AppCompatActivity() {

    //food item details
    private lateinit var foodName: String
    private lateinit var foodPrice: String
    private var foodImageUri: Uri? =null
    //firebase variables
    private lateinit var auth: FirebaseAuth //to authenticate the user
    private lateinit var database: FirebaseDatabase //to store data into firebase


    private val binding:ActivityAddItemBinding by lazy{
        ActivityAddItemBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        //to initialise the firebase
        auth=FirebaseAuth.getInstance()

        //initialise firebase database instance
        database= FirebaseDatabase.getInstance()

        binding.AddItemButton.setOnClickListener{
            // get data from fields
            foodName=binding.foodName.text.toString().trim()
            foodPrice=binding.foodPrice.text.toString().trim()

            if(!(foodName.isBlank() || foodPrice.isBlank())){
                uploadData()
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show()
                finish()
            }else{
                Toast.makeText(this, "Fill all the details", Toast.LENGTH_SHORT).show()
            }

        }
        binding.selectImage.setOnClickListener {
            pickImage.launch("image/*")
        }


    }

    private fun uploadData() {
        //get a reference to the menu node in the database(a node named menu will be created in the database)
        val menuRef = database.getReference("menu")

        // generate a unique key for the new menu item which is being added
        val newItemKey=menuRef.push().key

        if (foodImageUri!=null){
            val storageRef = FirebaseStorage.getInstance().reference
            val imageRef = storageRef.child("menu_images/${newItemKey}.jpg") //will convert the image and the unique key to jpg
            val uploadTask=imageRef.putFile(foodImageUri!!) //not null

            uploadTask.addOnSuccessListener {
                imageRef.downloadUrl.addOnSuccessListener {
                        downloadUrl->
                    //Create a new menu item
                    val newItem = AllMenu(
                        newItemKey,
                        foodName = foodName,
                        foodPrice= foodPrice,
                        foodImage = downloadUrl.toString(),
                    )
                    //create new unique for all the variables
                    newItemKey?.let{
                            key->
                        menuRef.child(key).setValue(newItem).addOnSuccessListener {
                            Toast.makeText(this, "data uploaded successfully", Toast.LENGTH_SHORT).show()
                        }
                            .addOnFailureListener{
                                Toast.makeText(this, "data upload failed", Toast.LENGTH_SHORT).show()
                            }
                    }
                }
            }
                .addOnFailureListener{
                    Toast.makeText(this, "image upload failed", Toast.LENGTH_SHORT).show()
                }

        }else{
            Toast.makeText(this, "please select an image", Toast.LENGTH_SHORT).show()
        }
    }

    private val pickImage =registerForActivityResult(ActivityResultContracts.GetContent()){ uri ->
        if(uri != null){
            binding.selectedImage.setImageURI(uri)
            foodImageUri=uri
        }
    }
}