package com.example.orderease.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import com.example.orderease.databinding.ActivityPopularItemsBinding

class PopularAdapter(
    private val originalItems: List<String>,
    private val originalPrice: List<String>,
    private val originalImages: List<Int>
) : RecyclerView.Adapter<PopularAdapter.PopularViewHolder>(), Filterable {

    private var filteredItems: List<String> = originalItems
    private var filteredPrice: List<String> = originalPrice
    private var filteredImages: List<Int> = originalImages

    inner class PopularViewHolder(private val binding: ActivityPopularItemsBinding) : RecyclerView.ViewHolder(binding.root) {
        private val imagesView = binding.foodImagePopular

        fun bind(item: String, price: String, images: Int) {
            binding.foodNamePopular.text = item
            binding.pricePopular.text = price
            imagesView.setImageResource(images)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PopularViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return PopularViewHolder(ActivityPopularItemsBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: PopularViewHolder, position: Int) {
        val item = filteredItems[position]
        val images = filteredImages[position]
        val price = filteredPrice[position]

        holder.bind(item, price, images)
    }

    override fun getItemCount(): Int {
        return filteredItems.size
    }

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val queryString = constraint?.toString()?.lowercase()

                val filterResults = FilterResults()
                filterResults.values = if (queryString.isNullOrBlank()) {
                    Triple(originalItems, originalPrice, originalImages)
                } else {
                    val filteredItems = mutableListOf<String>()
                    val filteredPrice = mutableListOf<String>()
                    val filteredImages = mutableListOf<Int>()

                    for (i in originalItems.indices) {
                        if (originalItems[i].lowercase().contains(queryString)) {
                            filteredItems.add(originalItems[i])
                            filteredPrice.add(originalPrice[i])
                            filteredImages.add(originalImages[i])
                        }
                    }

                    Triple(filteredItems, filteredPrice, filteredImages)
                }

                return filterResults
            }

            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                @Suppress("UNCHECKED_CAST")
                val triple = results?.values as Triple<List<String>, List<String>, List<Int>>

                filteredItems = triple.first
                filteredPrice = triple.second
                filteredImages = triple.third

                notifyDataSetChanged()
            }
        }
    }
}
