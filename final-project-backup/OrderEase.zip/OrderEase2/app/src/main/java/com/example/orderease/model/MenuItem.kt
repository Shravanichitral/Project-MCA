package com.example.orderease.model

data class MenuItem(
    val foodName :String?= null,
    val foodPrice :String?= null,
    val foodImage :String?= null,
)
