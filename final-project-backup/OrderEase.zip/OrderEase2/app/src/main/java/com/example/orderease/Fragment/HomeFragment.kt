package com.example.orderease.Fragment


import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.example.orderease.Gjbc
import com.example.orderease.NorthIndianActivity2
import com.example.orderease.PesMessActivity2
import com.example.orderease.R
import com.example.orderease.RoofTopActivity2
import com.example.orderease.SouthIndianActivity2

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        val cardView1: CardView = view.findViewById(R.id.card1)

       /* val cardView2: CardView = view.findViewById(R.id.card2)

        val cardView3: CardView = view.findViewById(R.id.card5)
        val cardView4: CardView = view.findViewById(R.id.card6)*/



        cardView1.setOnClickListener { onCardClick(NorthIndianActivity2::class.java) }

        /*cardView2.setOnClickListener { onCardClick(SouthIndianActivity2::class.java) }

        cardView3.setOnClickListener { onCardClick(RoofTopActivity2::class.java) }

        cardView4.setOnClickListener { onCardClick(PesMessActivity2::class.java) }*/



        return view
    }

    private fun onCardClick(activityClass: Class<*>) {
        val intent = Intent(requireActivity(), activityClass)
        startActivity(intent)
    }

    companion object {
        // You can add companion object functions or variables here if needed
        fun newInstance(): HomeFragment {
            return HomeFragment()
        }
    }
}
