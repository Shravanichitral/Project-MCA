package com.example.orderease

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.orderease.databinding.ActivityPopularItemsBinding
import com.example.orderease.model.CartItems
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class PopularItems : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityPopularItemsBinding
    private var foodName: String? = null
    private var foodImage: String? = null
    private var foodPrice: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPopularItemsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize firebaseAuth
        auth = FirebaseAuth.getInstance()

        // Get intent extras
        foodName = intent.getStringExtra("MenuItemName")
        foodPrice = intent.getStringExtra("MenuItemPrice")
        foodImage = intent.getStringExtra("MenuItemImage")

        Log.d("PopularItems", "Food Name: $foodName, Food Price: $foodPrice, Food Image: $foodImage")

        /*binding.addItemButton.setOnClickListener {
            addItemToCart()
        }*/
    }

   /* private fun addItemToCart() {
        val database = FirebaseDatabase.getInstance().reference // Getting the database reference
        val userId = auth.currentUser?.uid ?: "" // Current user ID

        Log.d("PopularItems", "User ID: $userId")

        // Check if user is authenticated
        if (userId.isEmpty()) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
            return
        }

        // Check if intent extras are null
        if (foodName.isNullOrEmpty() || foodPrice.isNullOrEmpty() || foodImage.isNullOrEmpty()) {
            Toast.makeText(this, "Invalid item data", Toast.LENGTH_SHORT).show()
            return
        }

        // Create CartItems object
        val cartItem = CartItems(foodName!!, foodPrice!!, foodImage!!, 1)

        // Save the data in the cart to Firebase
        database.child("user").child(userId).child("cartItems").push().setValue(cartItem)
            .addOnSuccessListener {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("PopularItems", "Error adding item to cart", e)
                Toast.makeText(this, "Failed to add item to cart", Toast.LENGTH_SHORT).show()
            }
    }*/
}
