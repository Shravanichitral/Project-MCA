package com.example.orderease.Fragment

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.orderease.adapter.BuyAgainAdapter
import com.example.orderease.databinding.FragmentHistoryBinding
import com.example.orderease.model.OrderDetails
import com.example.orderease.recentOrderItems
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class HistoryFragment : Fragment() {

    private lateinit var binding: FragmentHistoryBinding
    private lateinit var buyAgainAdapter: BuyAgainAdapter
    private lateinit var databaseReference: DatabaseReference
    private lateinit var database: FirebaseDatabase
    private lateinit var auth: FirebaseAuth
    private lateinit var userId: String
    private var listOfOrderItem: MutableList<OrderDetails> = mutableListOf()
    private var orderAcceptedListener: ValueEventListener? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHistoryBinding.inflate(inflater, container, false)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        userId = auth.currentUser?.uid ?: ""

        //retrieve and display the user order history
        retrieveBuyHistory()

        //recent buy button click
        binding.recentbuyitem.setOnClickListener{
            seeItemsRecentBuy()
        }

        //receivedButton click listener
        binding.receivedButton.setOnClickListener {
            val position = binding.BuyAgainRecyclerView.getChildAdapterPosition(binding.BuyAgainRecyclerView.getChildAt(0))
            updatePaymentReceived(position)
        }

        // cancelOrder button click listener
        binding.orderCancel.setOnClickListener {
            if (binding.orderCancel.visibility == View.VISIBLE) {
                deleteOrderData()
            }
        }

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        // Listen for changes in orderAccepted status
        startOrderAcceptedListener()
    }

    override fun onPause() {
        super.onPause()
        // Remove orderAccepted listener to avoid memory leaks
        stopOrderAcceptedListener()
    }

    private fun startOrderAcceptedListener() {
        orderAcceptedListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Check if orderAccepted is true for the current order
                val recentOrderItem = listOfOrderItem.firstOrNull()
                recentOrderItem?.let { orderDetails ->
                    val orderAccepted = snapshot.child(orderDetails.itemPushKey!!).child("orderAccepted").getValue(Boolean::class.java) ?: false
                    if (orderAccepted) {
                        // Order is accepted, disable the cancel button
                        binding.orderCancel.isEnabled = false
                        binding.orderCancel.alpha = 0.5f
                        // Notify user
                        Toast.makeText(requireContext(), "Order is Accepted by the canteen", Toast.LENGTH_SHORT).show()
                    } else {
                        // If order is not accepted, enable the cancel button
                        binding.orderCancel.isEnabled = true
                        binding.orderCancel.alpha = 1f
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        }

        // Add the listener to BuyHistory node
        database.reference.child("user").child(userId).child("BuyHistory")
            .addValueEventListener(orderAcceptedListener!!)
    }


    private fun stopOrderAcceptedListener() {
        // Remove the listener to avoid memory leaks
        orderAcceptedListener?.let {
            database.reference.child("user").child(userId).child("BuyHistory")
                .removeEventListener(it)
        }
    }

    private fun seeItemsRecentBuy() {
        if (listOfOrderItem.isNotEmpty()) {
            val intent = Intent(requireContext(), recentOrderItems::class.java)
            intent.putExtra("RecentBuyOrderItem", ArrayList(listOfOrderItem))
            startActivity(intent)
        }
    }

    private fun retrieveBuyHistory() {
        binding.recentbuyitem.visibility = View.INVISIBLE

        val buyItemReference: DatabaseReference =
            database.reference.child("user").child(userId).child("BuyHistory")
        val query = buyItemReference.orderByChild("currentTime")

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                listOfOrderItem.clear()
                for (buySnapshot in snapshot.children) {
                    val buyHistoryItem = buySnapshot.getValue(OrderDetails::class.java)
                    buyHistoryItem?.let {
                        listOfOrderItem.add(it)
                    }
                }
                listOfOrderItem.reverse()
                if (listOfOrderItem.isNotEmpty()) {
                    setDataInRecentBuyItem()
                    setPreviousBuyItemsRecyclerView()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    private fun setDataInRecentBuyItem() {
        binding.recentbuyitem.visibility = View.VISIBLE
        val recentOrderItem = listOfOrderItem.firstOrNull()
        recentOrderItem?.let {
            with(binding) {
                buyAgainFoodName.text = it.foodNames?.firstOrNull() ?: ""
                buyAgainFoodPrice.text = it.foodPrices?.firstOrNull() ?: ""
                val image = it.foodImages?.firstOrNull() ?: ""
                val uri = Uri.parse(image)
                Glide.with(requireContext()).load(uri).into(buyAgainFoodImage)

                val isOrderIsAccepted = listOfOrderItem[0].orderAccepted
                if (isOrderIsAccepted) {
                    orderedStatus.background.setTint(Color.GREEN)
                    receivedButton.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun setPreviousBuyItemsRecyclerView() {
        val buyAgainFoodName = mutableListOf<String>()
        val buyAgainFoodPrice = mutableListOf<String>()
        val buyAgainFoodImage = mutableListOf<String>()

        listOfOrderItem.forEach { orderDetails ->
            orderDetails.foodNames?.forEach { foodName ->
                buyAgainFoodName.add(foodName)
            }
            orderDetails.foodPrices?.forEach { foodPrice ->
                buyAgainFoodPrice.add(foodPrice)
            }
            orderDetails.foodImages?.forEach { foodImage ->
                buyAgainFoodImage.add(foodImage)
            }
        }

        val rv = binding.BuyAgainRecyclerView
        rv.layoutManager = LinearLayoutManager(requireContext())
        buyAgainAdapter = BuyAgainAdapter(
            buyAgainFoodName,
            buyAgainFoodPrice,
            buyAgainFoodImage,
            requireContext()
        )
        rv.adapter = buyAgainAdapter
    }

    private fun updatePaymentReceived(position: Int) {
        val itemPushKey = listOfOrderItem[position].itemPushKey
        val userBuyHistoryRef = database.reference.child("user").child(userId).child("BuyHistory").child(itemPushKey!!)
        val completedOrderRef = database.reference.child("CompletedOrder").child(itemPushKey)

        // Set paymentReceived to true in BuyHistory
        userBuyHistoryRef.child("paymentReceived").setValue(true)

        // Set paymentReceived to true in CompletedOrder
        completedOrderRef.child("paymentReceived").setValue(true)
    }

    private fun deleteOrderData() {
        val recentOrderItem = listOfOrderItem.firstOrNull()
        recentOrderItem?.let { orderDetails ->
            val itemPushKey = orderDetails.itemPushKey
            val userBuyHistoryRef = database.reference.child("user").child(userId).child("BuyHistory").child(itemPushKey!!)
            val orderDetailsRef = database.reference.child("OrderDetails").child(itemPushKey)
            val cardAmountRef = database.reference.child("user").child(userId).child("card").child("CardAmount")

            // Check if the order is accepted
            userBuyHistoryRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val orderAccepted = snapshot.child("orderAccepted").getValue(Boolean::class.java) ?: false
                    if (!orderAccepted) {
                        // Get the total amount of the cancelled order
                        val totalPriceString = orderDetails.totalPrice ?: "0.0"
                        val totalAmount = try {
                            totalPriceString.toDouble()
                        } catch (e: NumberFormatException) {
                            0.0
                        }

                        // Delete data from BuyHistory and OrderDetails nodes
                        userBuyHistoryRef.removeValue()
                        orderDetailsRef.removeValue()

                        // Add back the total amount to the CardAmount
                        cardAmountRef.addListenerForSingleValueEvent(object : ValueEventListener {
                            override fun onDataChange(cardSnapshot: DataSnapshot) {
                                val currentAmount = cardSnapshot.getValue(Double::class.java) ?: 0.0
                                val updatedAmount = currentAmount + totalAmount
                                cardAmountRef.setValue(updatedAmount)
                            }

                            override fun onCancelled(cardError: DatabaseError) {
                                // Handle error
                            }
                        })

                        Toast.makeText(requireContext(), "Order cancelled successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "Order is Accepted by the canteen and cannot be cancelled", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle error
                }
            })
        }
    }



}
