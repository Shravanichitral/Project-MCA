package com.example.orderease.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.orderease.databinding.OrderDetailsCardBinding
import com.example.orderease.model.OrderDetails
import com.example.orderease.recentOrderItems
import com.google.firebase.database.FirebaseDatabase

class CurrentOrderAdapter(
    private val context: Context,
    private val orderList: List<OrderDetails>,
    private var database: FirebaseDatabase,
    private var listOfOrderItem: MutableList<OrderDetails> = mutableListOf()
) : RecyclerView.Adapter    <CurrentOrderAdapter.ViewHolder>() {

    interface OrderClickListener {
        fun onReceivedButtonClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = OrderDetailsCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding, listOfOrderItem)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val order = orderList[position]
        holder.bind(order)
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    inner class ViewHolder(private val binding: OrderDetailsCardBinding, private val listOfOrderItem: MutableList<OrderDetails>) : RecyclerView.ViewHolder(binding.root), View.OnClickListener {
        init {
            // Set OnClickListener to the entire card
            binding.root.setOnClickListener(this)
        }

        override fun onClick(view: View?) {
            val position = adapterPosition
            if (position!= RecyclerView.NO_POSITION) {
                val orderDetails = orderList[position]
                val intent = Intent(context, recentOrderItems::class.java)
                intent.putExtra("OrderDetails", orderDetails) // Pass the OrderDetails object
                context.startActivity(intent)
            }
        }

        fun bind(order: OrderDetails) {
            with(binding) {
                buyAgainFoodName.text = order.foodNames?.firstOrNull() ?: ""
                buyAgainFoodPrice.text = order.foodPrices?.firstOrNull() ?: ""

                val image = order.foodImages?.firstOrNull() ?: ""
                val uri = Uri.parse(image)
                Glide.with(context).load(uri).into(buyAgainFoodImage)

                val isOrderAccepted = order.orderAccepted
                if (isOrderAccepted) {
                    orderedStatus.setCardBackgroundColor(Color.GREEN)
                    receivedButton.visibility = View.VISIBLE
                } else {
                    orderedStatus.setCardBackgroundColor(Color.parseColor("#98A398"))
                    receivedButton.visibility = View.INVISIBLE
                }

                receivedButton.setOnClickListener {
                    if (listOfOrderItem.isNotEmpty()) {
                        val isOrderIsAccepted = listOfOrderItem[0].orderAccepted
                        if (isOrderIsAccepted) {
                            orderedStatus.background.setTint(Color.GREEN)
                            receivedButton.visibility = View.VISIBLE
                        }
                    }
                }
            }
        }
    }
}
