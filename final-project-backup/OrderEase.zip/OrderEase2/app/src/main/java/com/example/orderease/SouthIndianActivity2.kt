package com.example.orderease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.orderease.adapter.PopularAdapter

class SouthIndianActivity2 : AppCompatActivity() {

    private lateinit var adapter: PopularAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_south_indian2)

        val foodName1 = listOf("idly", "dosa", "rice", "vada", "curd rice", "Coffee", "tea", "vada pav", "Pizza","item","vodka")
        val price1 = listOf("30/-", "50/-", "40/-", "25/-", "50/-", "10/-", "10/-", "20/-", "120/-","1/-","500/-")
        val popularFoodImages1 = listOf(R.drawable.idly, R.drawable.dosa, R.drawable.friedrice, R.drawable.vada, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.burgeritem, R.drawable.burgeritem)

        adapter = PopularAdapter(foodName1, price1, popularFoodImages1)
        recyclerView = findViewById(R.id.PopularRecyclerView1)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val searchView = findViewById<SearchView>(R.id.searchViewIcon)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return false
            }
        })
    }
}