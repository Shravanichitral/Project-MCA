package com.example.orderease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class BeBlock : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_be_block)
    }
}