package com.example.orderease.model

data class UserModel(
    //to store the data entered while registering
    val name:String?=null,
    val email:String?=null,
    val password:String?=null,
    val phone:String?=null,
)
