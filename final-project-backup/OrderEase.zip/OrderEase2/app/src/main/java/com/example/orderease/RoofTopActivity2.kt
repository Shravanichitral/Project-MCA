package com.example.orderease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.orderease.adapter.PopularAdapter

class RoofTopActivity2 : AppCompatActivity() {

    private lateinit var adapter: PopularAdapter
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_roof_top2)

        val foodName3 = listOf("Burger", "Sandwich", "momos", "Pani puri", "Pav bhaji", "Coffee", "tea", "vada pav", "Pizza")
        val price3 = listOf("60/-", "70/-", "90/-", "25/-", "100/-", "10/-", "10/-", "20/-", "120/-")
        val popularFoodImages3 = listOf(R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem)

        adapter = PopularAdapter(foodName3, price3, popularFoodImages3)
        recyclerView = findViewById(R.id.PopularRecyclerView3)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        val searchView = findViewById<SearchView>(R.id.searchViewIcon)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter.filter(newText)
                return false
            }
        })


    }
}