// LoadMoneyToCard.kt
package com.example.orderease

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import org.json.JSONObject

class LoadMoneyToCard : AppCompatActivity(), PaymentResultListener {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var userReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_load_money_to_card)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        userReference = database.reference.child("user").child(auth.currentUser?.uid.orEmpty()).child("card")

        val cardAmountEditText: EditText = findViewById(R.id.cardAmount)
        val loadFundsButton: Button = findViewById(R.id.loadFundsToCard)

        loadFundsButton.setOnClickListener {
            val amount = cardAmountEditText.text.toString()
            if (amount.isNotEmpty()) {
                startRazorpayPayment(amount)
            } else {
                // Handle case when amount is not entered
            }
        }
    }

    private fun startRazorpayPayment(amount: String) {
        val checkout = Checkout()
        checkout.setKeyID("rzp_test_OoZOF9W4rD0XOT") // Replace with your Razorpay test key ID

        try {
            val options = JSONObject()
            options.put("name", "Your App Name")
            options.put("description", "Adding Money to Card")
            options.put("currency", "INR") // Change to your desired currency code
            options.put("amount", amount.toDouble() * 100) // Amount should be in paisa, so multiply by 100 for rupees
            val jsonObject = JSONObject()
            jsonObject.put("order_amount", amount.toDouble()) // Optional additional parameter
            options.put("prefill", jsonObject)

            checkout.open(this, options)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        Toast.makeText(this, "Payment Successful: $razorpayPaymentId", Toast.LENGTH_SHORT).show()

        // Update card amount in Firebase
        updateCardAmount(razorpayPaymentId)
    }

    override fun onPaymentError(code: Int, message: String?) {
        Toast.makeText(this, "Payment failed: $message", Toast.LENGTH_SHORT).show()
        // Handle payment failure here
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Call the Razorpay onActivityResult method
        val checkout = Checkout()
        checkout.onActivityResult(requestCode, resultCode, data)
    }

    private fun updateCardAmount(paymentId: String?) {
        val amount = findViewById<EditText>(R.id.cardAmount).text.toString().toDouble()
        userReference.child("CardAmount").get().addOnSuccessListener { snapshot ->
            val currentAmount = if (snapshot.exists()) snapshot.getValue(Double::class.java) ?: 0.0 else 0.0
            val newAmount = currentAmount + amount
            userReference.child("CardAmount").setValue(newAmount)
        }.addOnFailureListener { e ->
            Toast.makeText(this, "Failed to update card amount: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
