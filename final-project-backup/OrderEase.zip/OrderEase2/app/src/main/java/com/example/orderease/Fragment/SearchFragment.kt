package com.example.orderease.Fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.orderease.LoadMoneyToCard
import com.example.orderease.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class SearchFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var userReference: DatabaseReference
    private lateinit var cardMainBalanceTextView: TextView
    private lateinit var cardHolderNameTextView: TextView
    private lateinit var cardNumberTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_search, container, false)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        userReference = database.reference.child("user").child(auth.currentUser?.uid.orEmpty()).child("card")
        cardMainBalanceTextView = view.findViewById(R.id.cardMainBalance)
        cardHolderNameTextView = view.findViewById(R.id.cardHolderName)
        cardNumberTextView = view.findViewById(R.id.cardNumber)

        val buttonLoadBalance: Button = view.findViewById(R.id.loadBalance)
        buttonLoadBalance.setOnClickListener {
            // Navigate to LoadMoneyToCard activity
            startActivity(Intent(requireContext(), LoadMoneyToCard::class.java))
        }

        // Display existing card balance
        userReference.child("CardAmount").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val cardBalance = dataSnapshot.getValue(Double::class.java)
                cardMainBalanceTextView.text = "${cardBalance ?: 0.0}"
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to read card balance.", Toast.LENGTH_SHORT).show()
            }
        })

        // Display user's name
        val userReference = database.reference.child("user").child(auth.currentUser?.uid.orEmpty())
        userReference.child("name").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val name = dataSnapshot.getValue(String::class.java)
                cardHolderNameTextView.text = name.orEmpty()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to read user's name.", Toast.LENGTH_SHORT).show()
            }
        })

        // Display user's phone number
        userReference.child("phone").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val phone = dataSnapshot.getValue(String::class.java)
                cardNumberTextView.text = phone.orEmpty()
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to read user's phone number.", Toast.LENGTH_SHORT).show()
            }
        })

        return view
    }
}
