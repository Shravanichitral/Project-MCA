package com.example.orderease

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.orderease.databinding.ActivitySignIn2Binding
import com.example.orderease.model.UserModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class SignInActivity2 : AppCompatActivity() {

    private lateinit var userName: String
    private lateinit var email: String
    private lateinit var password: String
    private lateinit var auth: FirebaseAuth

    private lateinit var database: DatabaseReference

    private val binding: ActivitySignIn2Binding by lazy {
        ActivitySignIn2Binding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()
        // Initialize Firebase database
        database = FirebaseDatabase.getInstance().reference

        binding.createUserButton.setOnClickListener {
            userName = binding.name.text.toString().trim()
            email = binding.email.text.toString().trim()
            password = binding.password.text.toString().trim()

            if (isValidName(userName) && isValidPassword(password)) {
                createAccount(email, password)
            } else {
                if (!isValidName(userName)) {
                    binding.name.error = getErrorMessageForName(userName)
                }
                if (!isValidPassword(password)) {
                    binding.password.error = getErrorMessageForPassword(password)
                }
            }
        }

        binding.registertologin.setOnClickListener {
            val intent = Intent(this, LoginActivity2::class.java)
            startActivity(intent)
        }
    }

    private fun createAccount(email: String, password: String) {
        database.child("user").orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    if (snapshot.exists()) {
                        Toast.makeText(
                            this@SignInActivity2,
                            "User email already exists",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        auth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    saveUserData()
                                    Toast.makeText(
                                        this@SignInActivity2,
                                        "Account created successfully",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    val intent = Intent(this@SignInActivity2, LoginActivity2::class.java)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    Toast.makeText(
                                        this@SignInActivity2,
                                        "Account creation failed",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    Log.d("Account", "createAccount: Failure", task.exception)
                                }
                            }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.d("Database", "Error checking email existence", error.toException())
                }
            })
    }

    private fun saveUserData() {
        // retrieve data from input field
        userName = binding.name.text.toString().trim()
        email = binding.email.text.toString().trim()
        password = binding.password.text.toString().trim()
        val user = UserModel(userName, email, password)
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        if (userId != null) {
            //save data to Firebase database
            database.child("user").child(userId).setValue(user)
        }
    }

    private fun isValidName(name: String): Boolean {
        val nameRegex = Regex("^[a-zA-Z ]{1,25}\$")
        return nameRegex.matches(name)
    }

    private fun isValidPassword(password: String): Boolean {
        val passwordRegex =
            Regex("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+\$).{8,15}\$")
        return passwordRegex.matches(password)
    }

    private fun getErrorMessageForName(name: String): String {
        return when {
            name.contains("\\d".toRegex()) -> "Name should not contain any numbers"
            name.contains("[^a-zA-Z\\s]".toRegex()) -> "Name should not contain any special characters apart from spaces"
            name.length > 25 -> "Name should not be more than 25 characters"
            else -> "Invalid name format"
        }
    }

    private fun getErrorMessageForPassword(password: String): String {
        return when {
            password.length < 8 -> "Password should be more than 8 characters"
            password.length > 15 -> "Password should not be more than 15 characters"
            password.contains("\\s".toRegex()) -> "Password should not contain any spaces"
            !password.contains("\\d".toRegex()) -> "Password should contain minimum 1 digit"
            !password.contains("[A-Z]".toRegex()) -> "Password should contain minimum 1 upper case letter"
            !password.contains("[a-z]".toRegex()) -> "Password should contain minimum 1 lower case letter"
            !password.contains("[@#$%^&+=!]".toRegex()) -> "Password should contain minimum 1 special character"
            else -> "Invalid password format"
        }
    }
}
