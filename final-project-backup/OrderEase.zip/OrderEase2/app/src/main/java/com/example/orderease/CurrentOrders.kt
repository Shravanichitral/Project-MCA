package com.example.orderease

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.orderease.adapter.CurrentOrderAdapter
import com.example.orderease.databinding.ActivityCurrentOrdersBinding
import com.example.orderease.model.OrderDetails
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class CurrentOrders : AppCompatActivity() {

    private lateinit var binding: ActivityCurrentOrdersBinding
    private lateinit var currentOrderAdapter: CurrentOrderAdapter
    private lateinit var databaseReference: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var userId: String
    private var orderList: MutableList<OrderDetails> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCurrentOrdersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        userId = auth.currentUser?.uid ?: ""
        databaseReference = FirebaseDatabase.getInstance().reference.child("user").child(userId).child("BuyHistory")

        setupRecyclerView()
        retrieveDataFromDatabase()
    }

    private fun setupRecyclerView() {
        binding.currentOrderRecyclerView.layoutManager = LinearLayoutManager(this)
        val database = FirebaseDatabase.getInstance() // Instantiate Firebase database here
        currentOrderAdapter = CurrentOrderAdapter(this, orderList, database)
        binding.currentOrderRecyclerView.adapter = currentOrderAdapter
    }

    private fun retrieveDataFromDatabase() {
        databaseReference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                orderList.clear()
                for (orderSnapshot in snapshot.children) {
                    val order = orderSnapshot.getValue(OrderDetails::class.java)
                    order?.let {
                        orderList.add(it)
                    }
                }
                currentOrderAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }
}