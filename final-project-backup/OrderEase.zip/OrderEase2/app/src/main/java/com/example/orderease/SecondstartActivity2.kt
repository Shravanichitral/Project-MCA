package com.example.orderease

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.orderease.databinding.ActivitySecondstart2Binding

class SecondstartActivity2 : AppCompatActivity() {
    private val binding: ActivitySecondstart2Binding by lazy {
        ActivitySecondstart2Binding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.nextbutton.setOnClickListener {
            val intent = Intent(this, LoginActivity2::class.java)
            startActivity(intent)
        }
    }
}
