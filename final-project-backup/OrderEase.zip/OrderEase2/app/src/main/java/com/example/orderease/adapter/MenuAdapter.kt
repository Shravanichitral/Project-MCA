package com.example.orderease.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.orderease.DetailsActivity
import com.example.orderease.databinding.ActivityPopularItemsBinding
import com.example.orderease.model.MenuItem
import com.google.firebase.database.DatabaseReference

class MenuAdapter(
    private val context: Context,
    private val menuList: List<MenuItem>,
    //private val requireContext: Context,
    databaseReference: DatabaseReference
): RecyclerView.Adapter<MenuAdapter.MenuViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val binding = ActivityPopularItemsBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return MenuViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        holder.bind(position)
    }
    override fun getItemCount(): Int = menuList.size //how mny ever items are added it will show in the recycler view

    inner class MenuViewHolder(private val binding: ActivityPopularItemsBinding): RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener{
                val position=adapterPosition
                if(position != RecyclerView.NO_POSITION){
                    openDetailsActivity(position)
                }
            }
        }

        private fun openDetailsActivity(position: Int){
            val menuItem= menuList[position]

            //an intent to open details activity and pass data
            val intent = Intent(context, DetailsActivity::class.java).apply {
                putExtra("MenuItemName",menuItem.foodName)
                putExtra("MenuItemImage",menuItem.foodImage)
                putExtra("MenuItemPrice",menuItem.foodPrice)
            }
            //start the details Activity
            context.startActivity(intent)
        }
        //set data into recyclerview item name,price,image
        fun bind(position: Int) {
            binding.apply {
                val menuItem= menuList[position]
                val uriString=menuItem.foodImage
                val uri= Uri.parse(uriString)
                foodNamePopular.text = menuItem.foodName
                pricePopular.text = menuItem.foodPrice
                Glide.with(context).load(uri).into(foodImagePopular)

            }
        }

    }
}




