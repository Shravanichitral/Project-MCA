package com.example.orderease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.orderease.adapter.RecentBuyAdapter
import com.example.orderease.databinding.ActivityRecentOrderItemsBinding
import com.example.orderease.model.OrderDetails

class recentOrderItems : AppCompatActivity() {
    private lateinit var binding: ActivityRecentOrderItemsBinding
    private var allFoodNames: ArrayList<String> = ArrayList()
    private var allFoodImages: ArrayList<String> = ArrayList()
    private var allFoodPrices: ArrayList<String> = ArrayList()
    private var allFoodQuantities: ArrayList<Int> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecentOrderItemsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val recentOrderItems = intent.getSerializableExtra("RecentBuyOrderItem") as? ArrayList<OrderDetails>
        recentOrderItems?.let { orderDetails ->
            if (orderDetails.isNotEmpty()) {
                val recentOrderItem = orderDetails[0]

                allFoodNames.addAll(recentOrderItem.foodNames ?: mutableListOf())
                allFoodImages.addAll(recentOrderItem.foodImages ?: mutableListOf())
                allFoodPrices.addAll(recentOrderItem.foodPrices ?: mutableListOf())
                allFoodQuantities.addAll(recentOrderItem.foodQuantities ?: mutableListOf())
            }

            setAdapter()
        }
    }

    private fun setAdapter() {
        val rv = binding.recyclerViewRecentBuy
        rv.layoutManager = LinearLayoutManager(this)
        val adapter = RecentBuyAdapter(this, allFoodNames, allFoodImages, allFoodPrices, allFoodQuantities)
        rv.adapter = adapter
    }
}
