package com.example.orderease

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.orderease.databinding.ActivityPayOutBinding
import com.example.orderease.model.OrderDetails
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PayOutActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var name: String
    private lateinit var phone: String
    private lateinit var totalAmount: String
    private lateinit var foodItemName: ArrayList<String>
    private lateinit var foodItemPrice: ArrayList<String>
    private lateinit var foodItemImage: ArrayList<String>
    private lateinit var foodItemQuantities: ArrayList<Int>
    private lateinit var databaseReference: DatabaseReference
    private lateinit var userId: String
    lateinit var binding: ActivityPayOutBinding
    lateinit var editAmount: EditText
    lateinit var btnPayNow: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPayOutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //initialize firebase and user details
        auth = FirebaseAuth.getInstance()
        databaseReference = FirebaseDatabase.getInstance().getReference()

        //set user data
        setUserData()

        //get user details from firebase
        val intent = intent
        foodItemName = intent.getStringArrayListExtra("FoodItemName") as ArrayList<String>
        foodItemPrice = intent.getStringArrayListExtra("FoodItemPrice") as ArrayList<String>
        foodItemImage = intent.getStringArrayListExtra("FoodItemImage") as ArrayList<String>
        foodItemQuantities = intent.getIntegerArrayListExtra("FoodItemQuantities") as ArrayList<Int>

        //calculate the price
        totalAmount = calculateTotalAmount().toString()
        //binding.totalAmount.isEnabled=false
        binding.totalAmount.setText(totalAmount)

        editAmount = findViewById(R.id.totalAmount)
        btnPayNow = findViewById(R.id.PlaceMyOrder)

        binding.PlaceMyOrder.setOnClickListener {
            //get data from textview
            name = binding.name.text.toString().trim()
            phone = binding.phone.text.toString().trim()
            if (name.isBlank() && phone.isBlank()) {
                Toast.makeText(this, "Please enter all the details", Toast.LENGTH_SHORT).show()
            } else {
                placeOrder()
            }
        }
    }

    private fun placeOrder() {
        userId = auth.currentUser?.uid ?: ""
        val time = System.currentTimeMillis()
        val itemPushKey = databaseReference.child("OrderDetails").push().key
        val orderDetails = OrderDetails(
            userId,
            name,
            foodItemName,
            foodItemPrice,
            foodItemImage,
            foodItemQuantities,
            totalAmount,
            phone,
            time,
            itemPushKey,
            false,
            false
        )

        // Fetch card balance from database
        val cardReference = databaseReference.child("user").child(userId).child("card").child("CardAmount")
        cardReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val cardAmount = dataSnapshot.getValue(Double::class.java) ?: 0.0
                if (totalAmount.toDouble() <= cardAmount) {
                    // Place order if sufficient funds are available
                    val orderReference = databaseReference.child("OrderDetails").child(itemPushKey!!)
                    orderReference.setValue(orderDetails).addOnSuccessListener {
                        val bottomSheetDialog = CongratsBottomSheet()
                        bottomSheetDialog.show(supportFragmentManager, "Test")

                        // Remove item from cart after the order is placed
                        removeItemFromCart()

                        // Deduct the order amount from the card balance
                        deductOrderAmountFromCardBalance(totalAmount.toInt())

                        addOrderToHistory(orderDetails)
                    }.addOnFailureListener {
                        Toast.makeText(this@PayOutActivity, "Failed to order🙁", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@PayOutActivity, "Insufficient funds in the wallet", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@PayOutActivity, "Failed to fetch card balance", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun addOrderToHistory(orderDetails: OrderDetails) {
        databaseReference.child("user").child(userId).child("BuyHistory")
            .child(orderDetails.itemPushKey!!)
            .setValue(orderDetails).addOnSuccessListener {

            }
    }

    private fun removeItemFromCart() {
        val cartItemsReference = databaseReference.child("user").child(userId).child("cartItems")
        cartItemsReference.removeValue()
    }

    private fun calculateTotalAmount(): Int {
        var totalAmount = 0
        for (i in 0 until foodItemPrice.size) {
            var price = foodItemPrice[i]
            val lastChar = price.last()
            val priceIntValue = if (lastChar == '₹') {
                price.dropLast(1).toInt()
            } else {
                price.toInt()
            }
            var quantity = foodItemQuantities[i]
            totalAmount += priceIntValue * quantity
        }
        return totalAmount
    }

    private fun setUserData() {
        val user = auth.currentUser
        if (user != null) {
            val userId = user.uid
            val userReference = databaseReference.child("user").child(userId)
            userReference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val names = snapshot.child("name").getValue(String::class.java) ?: ""
                        val phones = snapshot.child("phone").getValue(String::class.java) ?: ""

                        binding.apply {
                            name.setText(names)
                            phone.setText(phones)
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {

                }
            })
        }
    }

    private fun deductOrderAmountFromCardBalance(orderAmount: Int) {
        val cardReference =
            databaseReference.child("user").child(userId).child("card").child("CardAmount")
        cardReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val currentCardAmount = dataSnapshot.getValue(Double::class.java) ?: 0.0
                    val updatedCardAmount = currentCardAmount - orderAmount
                    if (updatedCardAmount >= 0) {
                        cardReference.setValue(updatedCardAmount)
                    } else {
                        Toast.makeText(
                            this@PayOutActivity,
                            "Insufficient balance in card",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@PayOutActivity,
                        "Card balance not found",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(
                    this@PayOutActivity,
                    "Failed to deduct amount from card balance",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    companion object {
        private fun deductOrderAmountFromCardBalance(payOutActivity: PayOutActivity, orderAmount: Int) {
            val cardReference = payOutActivity.databaseReference.child("user").child(payOutActivity.userId).child("card").child("CardAmount")
            cardReference.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    if (dataSnapshot.exists()) {
                        val currentCardAmount = dataSnapshot.getValue(Double::class.java) ?: 0.0
                        val updatedCardAmount = currentCardAmount - orderAmount
                        if (updatedCardAmount >= 0) {
                            cardReference.setValue(updatedCardAmount)
                        } else {
                            Toast.makeText(payOutActivity, "Insufficient balance in card Load the Funds", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(payOutActivity, "Card balance not found", Toast.LENGTH_SHORT).show()
                    }
                }
    
                override fun onCancelled(databaseError: DatabaseError) {
                    Toast.makeText(payOutActivity, "Failed to deduct amount from card balance", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}



