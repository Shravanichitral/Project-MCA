package com.example.orderease

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView

class ChooseLocationActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_location2)

        val cardView1: CardView = findViewById(R.id.card1)
        val cardView2: CardView = findViewById(R.id.card2)
        val cardView3: CardView = findViewById(R.id.card3)
        val cardView4: CardView = findViewById(R.id.card4)

        cardView1.setOnClickListener { onCardClick(Gjbc::class.java) }
        cardView2.setOnClickListener { onCardClick(BeBlock::class.java) }
        cardView3.setOnClickListener { onCardClick(MainActivity::class.java) }
        cardView4.setOnClickListener { onCardClick(PesShops::class.java) }
    }

    private fun onCardClick(activityClass: Class<*>) {
        val intent = Intent(this@ChooseLocationActivity2, activityClass)
        startActivity(intent)
    }
}
