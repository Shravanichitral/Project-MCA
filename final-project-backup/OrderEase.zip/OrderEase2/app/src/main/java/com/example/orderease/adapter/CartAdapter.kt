package com.example.orderease.adapter

import android.content.Context
import android.annotation.SuppressLint
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.orderease.databinding.CartItemBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CartAdapter(
    private val context: Context,
    private val CartItems: MutableList<String>,
    private val CartItemPrice: MutableList<String>,
    private val CartImage: MutableList<String>,
    private val CartQuantity: MutableList<Int>
) : RecyclerView.Adapter<CartAdapter.cartViewHolder>() {
    //instance firebase
    private val auth=FirebaseAuth.getInstance()

    init {
        //initialize the firebase
        val database=FirebaseDatabase.getInstance()
        val userId=auth.currentUser?.uid?:""
        val cartItemNumber=CartItems.size

       itemQuantities= IntArray(cartItemNumber){1}
        CartItemsReference=database.reference.child("user").child(userId).child("cartItems")
    }
    companion object{
        private var itemQuantities:IntArray= intArrayOf()
        private lateinit var CartItemsReference:DatabaseReference
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): cartViewHolder {
        val binding=CartItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return cartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: cartViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int = CartItems.size

    //get updated quantity
    @SuppressLint("SuspiciousIndentation")
    fun getUpdatedItemsQuantities(): MutableList<Int> {
    val itemQuantity= mutableListOf<Int>()
        itemQuantity.addAll(CartQuantity)
        return itemQuantity
    }

    inner class cartViewHolder(private val binding: CartItemBinding) :RecyclerView.ViewHolder(binding.root){
        @SuppressLint("SuspiciousIndentation")
        fun bind(position: Int) {
            binding.apply {
                val quantity = itemQuantities[position]
                cartFoodName.text = CartItems[position]
                cartItemPrice.text= CartItemPrice[position]

                //load image using glide
                val uriString=CartImage[position]
                val uri= Uri.parse(uriString)
                Glide.with(context).load(uri).into(cartImage)
                cartItemQuantity.text=quantity.toString()

                minusButton.setOnClickListener {
                    decreaseQuantity(position)
                }

                plusButton.setOnClickListener {
                    increaseQuantity(position)
                }
                deleteButton.setOnClickListener {
                  val itemPosition= adapterPosition
                    if(itemPosition != RecyclerView.NO_POSITION){
                        deleteItem(itemPosition)
                    }
                }



            }
        }

        private fun decreaseQuantity(position: Int) {
            if (itemQuantities[position] > 1) {
                itemQuantities[position]--
                CartQuantity[position]= itemQuantities[position]
                binding.cartItemQuantity.text = itemQuantities[position].toString()
            }
        }

        private fun increaseQuantity(position: Int){
            if(itemQuantities[position]<10){
                itemQuantities[position]++
                CartQuantity[position]= itemQuantities[position]
                binding.cartItemQuantity.text=itemQuantities[position].toString()
            }

        }

        private fun deleteItem(position: Int){
            val positionRetrieve=position
            getUniqueKeyAtPosition(positionRetrieve){uniqueKey ->
                if(uniqueKey != null){
                    removeItem(position,uniqueKey)
                }
            }

        }

        private fun removeItem(position: Int, uniqueKey: String) {
            if (uniqueKey != null){
                CartItemsReference.child(uniqueKey).removeValue().addOnSuccessListener {
                    CartItems.removeAt(position)
                    CartImage.removeAt(position)
                    CartQuantity.removeAt(position)
                    CartItemPrice.removeAt(position)

                    Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show()
                    //update item quantity after removing
                    itemQuantities = itemQuantities.filterIndexed { index, i -> index != position }.toIntArray()
                    notifyItemRemoved(position)
                    notifyItemRangeChanged(position,CartItems.size)
                }.addOnFailureListener{
                    Toast.makeText(context, "Failed to Delete", Toast.LENGTH_SHORT).show()
                }
            }
        }

        private fun getUniqueKeyAtPosition(positionRetrieve: Int, onComplete:(String?)-> Unit) {
            CartItemsReference.addListenerForSingleValueEvent(object : ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    var uniqueKey:String?=null
                    //loop for snapshot children
                    snapshot.children.forEachIndexed { index, dataSnapshot ->
                        if (index==positionRetrieve){
                            uniqueKey=dataSnapshot.key
                            return@forEachIndexed
                        }
                    }
                    onComplete(uniqueKey)
                }

                override fun onCancelled(error: DatabaseError) {

                }

            })
        }
    }

}