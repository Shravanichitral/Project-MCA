package com.example.orderease

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.orderease.databinding.ActivityDetailsBinding
import com.example.orderease.model.CartItems
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class DetailsActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityDetailsBinding
    private var foodName: String?=null
    private var foodImage: String?=null
    private var foodPrice: String?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth=FirebaseAuth.getInstance()

        foodName=intent.getStringExtra("MenuItemName")
        foodPrice=intent.getStringExtra("MenuItemPrice")
        foodImage=intent.getStringExtra("MenuItemImage")

        with(binding){
            detailFoodName.text = foodName
            detailFoodPrice.text = foodPrice
            Glide.with(this@DetailsActivity).load(Uri.parse(foodImage)).into(detailFoodImage)
        }


        binding.addToCart.setOnClickListener {
            addItemToCart()
        }
    }

    private fun addItemToCart() {
        val database = FirebaseDatabase.getInstance().reference // Getting the database reference
        val userId = auth.currentUser?.uid ?: "" // Current user ID

        Log.d("PopularItems", "User ID: $userId")

        // Check if user is authenticated
        if (userId.isEmpty()) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
            return
        }

        // Check if intent extras are null
        if (foodName.isNullOrEmpty() || foodPrice.isNullOrEmpty() || foodImage.isNullOrEmpty()) {
            Toast.makeText(this, "Invalid item data", Toast.LENGTH_SHORT).show()
            return
        }

        // Create CartItems object
        val cartItem = CartItems(foodName!!, foodPrice!!, foodImage!!, 1)

        // Save the data in the cart to Firebase
        database.child("user").child(userId).child("cartItems").push().setValue(cartItem)
            .addOnSuccessListener {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("PopularItems", "Error adding item to cart", e)
                Toast.makeText(this, "Failed to add item to cart", Toast.LENGTH_SHORT).show()
            }
    }
}