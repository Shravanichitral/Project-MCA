package com.example.orderease

import android.os.Bundle
import android.util.Log
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.orderease.adapter.MenuAdapter
import com.example.orderease.databinding.ActivityNorthIndian2Binding
import com.example.orderease.model.MenuItem
import com.google.firebase.database.*

class NorthIndianActivity2 : AppCompatActivity() {

    // Firebase variables
    private lateinit var databaseReference: DatabaseReference
    private lateinit var database: FirebaseDatabase

    private var menuItems: ArrayList<MenuItem> = ArrayList()
    private val binding: ActivityNorthIndian2Binding by lazy {
        ActivityNorthIndian2Binding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // Initialise
        databaseReference = FirebaseDatabase.getInstance("https://adminorderease-default-rtdb.firebaseio.com/").reference
        retrieveMenuItem()
        setupSearchView()
    }

    private fun setupSearchView() {
        binding.searchViewIcon.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                filterMenuItems(query)
                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                filterMenuItems(newText)
                return true
            }
        })
    }

    private fun filterMenuItems(query: String) {
        val filteredMenuItems = menuItems.filter {
            it.foodName?.contains(query, ignoreCase = true) == true
        }
        setAdapter(filteredMenuItems)
    }

    private fun retrieveMenuItem() {
        database = FirebaseDatabase.getInstance()
        val foodRef: DatabaseReference = database.reference.child("menu")

        // Fetch data from database where data is being fetched in the snapshot format
        foodRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Clear existing data before populating
                menuItems.clear()

                // Loop through each food item
                for (foodSnapshot in snapshot.children) { // Keeps checking the item and stores them
                    val menuItem = foodSnapshot.getValue(MenuItem::class.java)
                    menuItem?.let {
                        menuItems.add(it)
                    }
                }

                // Once the data is received set it to adapter
                setAdapter(menuItems)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("DatabaseError", "Error: ${error.message} ")
            }
        })
    }

    private fun setAdapter(filteredMenuItem: List<MenuItem>) {
        val adapter = MenuAdapter(this@NorthIndianActivity2, filteredMenuItem, databaseReference)
        binding.NorthRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.NorthRecyclerView.adapter = adapter
    }
}
