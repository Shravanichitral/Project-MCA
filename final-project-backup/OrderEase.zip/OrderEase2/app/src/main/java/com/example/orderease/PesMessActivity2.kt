package com.example.orderease

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.orderease.adapter.PopularAdapter

class PesMessActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pes_mess2)

        val foodName4 = listOf("Burger", "Sandwich", "momos", "Pani puri", "Pav bhaji", "Coffee", "tea", "vada pav", "Pizza","item-1","item-2")
        val price4 = listOf("60/-", "70/-", "90/-", "25/-", "100/-", "10/-", "10/-", "20/-", "120/-", "20/-", "120/-")
        val popularFoodImages4 = listOf(R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem, R.drawable.sandwichitem, R.drawable.burgeritem)

        val adapter = PopularAdapter(foodName4, price4, popularFoodImages4)
        val recyclerView = findViewById<RecyclerView>(R.id.PopularRecyclerView4)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }
}